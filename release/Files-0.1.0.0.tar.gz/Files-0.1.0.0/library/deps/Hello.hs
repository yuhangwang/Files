module Hello (hello) where

hello :: String -> String
hello s = "Hello " ++ s ++ "!"